import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ict300/api/AuthService.dart';
import 'package:ict300/api/localisation.dart';
import 'package:ict300/colors.dart';
import 'package:ict300/component/button.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:provider/provider.dart';
import 'package:ict300/Modal/geofancing.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

class AddPresence extends StatefulWidget {
  AddPresence({Key? key}) : super(key: key);

  @override
  State<AddPresence> createState() => _AddPresenceState();
}

class _AddPresenceState extends State<AddPresence> {
  LocationData? position;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    context.read<Localisation>().initLocation();

    Future.delayed(Duration(seconds: 5),() {
      setState(() {
        loading=false;
      });
    },);
  }


  @override
  void dispose() {
    super.dispose();
  }
bool loading =true;
  @override
  Widget build(BuildContext context) {
    final localisation = context.watch<Localisation>();
    final heigth = MediaQuery.of(context).size.height;
    final widht = MediaQuery.of(context).size.width;
    final authService = context.watch<AuthService>();

  //  print(localisation.location);
    return Scaffold(

      body: Stack(
  children: [
    Container(
    height: heigth,
    width: widht,
    decoration: BoxDecoration(
    image: DecorationImage(
    fit: BoxFit.cover,
    image: AssetImage("assets/images/maploc.jpeg"))),
    padding: EdgeInsets.all(16),
    child: ListView(
    children: [
    Card(
    elevation: 4,
    child: Container(
    width: widht * .95,
    height: 200,
    padding: EdgeInsets.all(16),
    child: Column(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Text("Longititue: "),
    Text(localisation.location == null
    ? ''
        : localisation.location!.longitude.toString())
    ],
    ),
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Text("Latitude: "),
    Text(localisation.location == null
    ? ""
        : localisation.location!.latitude.toString())


    ],
    ),
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Text("Pays: "),
    Text(localisation.addres == null
    ? ""
        : localisation.addres['country'].toString())  ],
    ),
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Text("localite: "),
    Text(localisation.addres == null
    ? ""
        : localisation.addres['locality'].toString())
    ],
    ),
    Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
    Text("Lieu: "),

    Text(localisation.addres == null
    ? ""
        : localisation.addres['name'].toString())
    ],
    ),
    ]),
    ),
    ),
    SizedBox(
    height: heigth * .05,
    ),
    if(!estAProximite(localisation.location == null
    ? 0
        : localisation.location!.latitude, localisation.location == null
    ? 0
        : localisation.location!.longitude))

    Image.asset('assets/images/icons8-georeperage (1).gif'),
    if(estAProximite(localisation.location == null
    ? 0
        : localisation.location!.latitude, localisation.location == null
    ? 0
        : localisation.location!.longitude))
    Text("Vous etes dans la zone marquer votre presence "),
    SizedBox(
    height:10,
    ),

    Align(
    alignment: Alignment.bottomCenter,
    child:Visibility(visible: estAProximite(localisation.location == null
    ? 0
        : localisation.location!.latitude, localisation.location == null
    ? 0
        : localisation.location!.longitude),
    child: GestureDetector(
    onTap: () {

    dynamic data = {
    "longitude": localisation.location!.longitude,
    "latitude": localisation.location!.latitude,
    "location":localisation.addres['locate'].toString() ,
    "personnel": authService.user!.id
    };
    setState(() {
      loading = true;
    });
    context
        .read<AuthService>()
        .addPresence(data)
        .then((value) {
      setState(() {
        loading = false;
      });
      showTopSnackBar(
        context,
        CustomSnackBar.success(
          message: "connecté",
        ),
      );
      Navigator.of(context).pop();
    }).catchError((err) {

      showTopSnackBar(
        context,
        CustomSnackBar.error(
          message: err.toString(),
        ),
      );
      setState(() {
        loading = false;
      });
    });

    },
    child: Container(
    alignment: Alignment.center,
    width: widht * .85,
    height: 45,

    child: Text("Marquer ma presence",
    style: TextStyle(
    fontSize: 18,
    color: whiteColor,
    fontFamily: "Roboto-Medium")),
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(10),
    color: kPrimaryColors),
    ),
    )) )
    ],
    )),
    loading?Container(decoration: BoxDecoration(color:Colors.black26),
      child: Align(
        alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
        children: [
            CircularProgressIndicator(color: kPrimaryColors,),
          Text("Georeperage du telephone mobile",style: TextStyle(color: whiteColor),)
        ],
      )),height:heigth ,width: widht,):Container()
  ])
    );
  }
}
