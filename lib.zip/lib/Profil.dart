import 'package:flutter/material.dart';
import 'package:ict300/api/AuthService.dart';
import 'package:ict300/api/DioClient.dart';
import 'package:ict300/colors.dart';
import 'package:provider/provider.dart';

class Profil extends StatefulWidget {
  Profil({Key? key}) : super(key: key);

  @override
  State<Profil> createState() => _ProfilState();
}

class _ProfilState extends State<Profil> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    context.read<AuthService>().getjour();
  }

  @override
  Widget build(BuildContext context) {
    final heigth = MediaQuery.of(context).size.height;
    final widht = MediaQuery.of(context).size.width;
    final auth = context.watch<AuthService>();
    return Scaffold(
      body: Container(
        height: heigth,
        width: widht,
        child: ListView(
          children: [
            Card(
              elevation: 2,
              child: Container(
                height: 214,
                width: 313,
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 60,
                      backgroundImage:
                          NetworkImage(baseurl + auth.user!.avatar!),
                    ),
                    Text(auth.user!.nom!,
                        style: TextStyle(
                            fontSize: 18,
                            color: kBlack,
                            fontFamily: "Roboto-Bold")),
                    Text(auth.user!.email!,
                        style: TextStyle(
                            fontSize: 15,
                            color: kBlack,
                            fontFamily: "Roboto-Regular")),
                  ],
                ),
              ),
            ),
            ListTile(
                leading: Icon(
                  Icons.person_outline,
                  size: 25,
                  color: kPrimaryColors,
                ),
                title: Text("Mon Compte",
                    maxLines: 2,
                    style: TextStyle(
                      fontFamily: "Poppins-medium",
                      color: kBlack,
                      fontSize: 14,
                    )),
                trailing: Icon(
                  Icons.arrow_forward_ios,
                  size: 25,
                )),
            Divider(
              color: kBlack,
            ),
            ListTile(
                leading: Icon(
                  Icons.settings_outlined,
                  size: 25,
                  color: kPrimaryColors,
                ),
                title: Text("Paramètres",
                    maxLines: 2,
                    style: TextStyle(
                      fontFamily: "Poppins-medium",
                      color: kBlack,
                      fontSize: 14,
                    )),
                trailing: Icon(
                  Icons.arrow_forward_ios,
                  size: 25,
                )),
            Divider(
              color: kBlack,
            ),
            GestureDetector(
              child: ListTile(
                  leading: Icon(
                    Icons.logout,
                    size: 25,
                    color: kPrimaryColors,
                  ),
                  title: Text("Déconnexion",
                      maxLines: 2,
                      style: TextStyle(
                        fontFamily: "Poppins-medium",
                        color: kBlack,
                        fontSize: 14,
                      )),
                  trailing: Icon(
                    Icons.arrow_forward_ios,
                    size: 25,
                  )),
              onTap: () => context.read<AuthService>().logout(),
            ),
            Divider(
              color: kBlack,
            ),
            ListTile(
                leading: Icon(
                  Icons.info,
                  size: 25,
                  color: kPrimaryColors,
                ),
                title: Text("A propos de nous",
                    maxLines: 2,
                    style: TextStyle(
                      fontFamily: "Poppins-medium",
                      color: kBlack,
                      fontSize: 14,
                    )),
                trailing: Icon(
                  Icons.arrow_forward_ios,
                  size: 25,
                )),
            Divider(
              color: kBlack,
            )
          ],
        ),
      ),
    );
  }
}
